<?php
$year = $_GET["year"];
$gender = $_GET["gender"];

if(empty($year) || empty($gender)) {
	header('Location: babynames.html');
}

$con = mysqli_connect("localhost", "root", "root", "hw3");
if (!$con){
	die("Connection Unsuccessful: " . mysqli_connect_error());
}

if($year=="All" && $gender=="Both"){
	$sql = "
		SELECT year, gender, ranking, name FROM babynames
		WHERE ranking <=5";
}
elseif($year=="All" && $gender!="Both"){
	$sql = "
		SELECT year, gender, ranking, name FROM babynames
		WHERE ranking <=5 AND gender='".$gender."' ";
}
elseif($year!="All" && $gender=="Both"){
	$sql = "
		SELECT year, gender, ranking, name FROM babynames
		WHERE ranking <=5 AND year='".$year."'   "; 
}
elseif($year!="All" && $gender!="Both"){
	$sql = "
		SELECT year, gender, ranking, name FROM babynames
		where ranking <=5 AND gender='".$gender."' AND year='".$year."'  ";
}

$result = mysqli_query($con, $sql);
echo "<center>
	<table border='1'>
	<tr>
	<th>Name</th>
	<th>Year</th>
	<th>Ranking</th>
	<th>Gender</th>
	</tr>
	</center>";
while($row = mysqli_fetch_array($result)){
	echo "<tr>";
	echo "<td>" . $row['name'] . "</td>";
	echo "<td>" . $row['year'] . "</td>";
	echo "<td>" . $row['ranking'] . "</td>";
	echo "<td>" . $row['gender'] . "</td>";
	echo "</tr>";
}
echo "</table>";
?>