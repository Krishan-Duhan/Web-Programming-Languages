function makeAjaxcal() {
	var year = document.getElementById("year").value;
	var gender = document.getElementById("gender").value;
	var disp = document.getElementById("display");
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET", "babynames.php?year=" + year + "&gender=" + gender, true);
	xmlhttp.send();
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			disp.innerHTML = xmlhttp.responseText;
		}
	}
}

function begin() {
	document.getElementById("Go").onclick = makeAjaxcal;
}

window.onload = begin;