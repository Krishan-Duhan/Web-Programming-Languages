$(document).ready(function(){
	$("#add").on('click', function(){
		var newTodo = $("#newtodo").val();
		console.log(newTodo);
		$('#newtodo').toggle();
		//$("ul").append("<li>" + newTodo + "</li>");

	});


	$("#newtodo").keypress(function(event){
			if (event.which === 13){
				var newTodo = $("#newtodo").val();
				console.log(newTodo);
				$("ul").append("<li>" + newTodo +'<button class = "trash" class="btn"><i class="fa fa-trash"></i></button>' +"</li>");
				$(".trash").hide();

			}
	});

	$("ul").on("mouseenter", "li", function(){
		$(this).find('button').show();
		var par = $(this);

		$(this).find('button').on('click', function() {
			par.remove();
		});

	});

	$("ul").on("mouseleave", "li", function(){
		$(this).find('button').hide();

	});

	$("ul").on("click", "li", function(){
		$(this).toggleClass("done");

	});
});